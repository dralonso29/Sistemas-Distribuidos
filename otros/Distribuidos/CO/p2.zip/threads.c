#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <ucontext.h>
#include <sys/time.h>

enum{
    sizeStack=64*1024,
    sizeArrayThreads=4,
    numMaxThreads=sizeArrayThreads+1
};


enum {
    Free=0,
    Ready=1, 
    Delete=2, 
    Using = 3,
    Suspend = 4,
    Sleep = 5
};


static int idthread=0;

static long long initTime();
static int scheduler (int j);


static struct thread{
    int id;
    long long t;
    char* stack;
    ucontext_t context;
    int usoThread;
    long long timeSleep;
}threadInit;

static struct thread arrayTh[sizeArrayThreads];


void
initthreads(void) {
    initTime();
    threadInit.id=idthread;
    threadInit.t=initTime();
    threadInit.stack = malloc(sizeStack);
    threadInit.usoThread = Using;
    threadInit.timeSleep=0;
    idthread++;
    
    threadInit.context.uc_stack.ss_sp = threadInit.stack;
    threadInit.context.uc_stack.ss_size = sizeStack;
    threadInit.context.uc_link = NULL; 
    arrayTh[0]= threadInit;
}


int
createthread(void (*mainf)(void*), void *arg, int stacksize){
    int id;
    id = -1;
    int i;
    for(i=0; i<sizeArrayThreads; i++){ //sizeArrayThreads+1
        if(arrayTh[i].usoThread == Free || arrayTh[i].usoThread == Delete){
            struct thread newthread;
            getcontext(&(newthread.context));

            newthread.id=idthread;
            id=newthread.id;
            newthread.usoThread = Ready;
            idthread++;

            newthread.t=initTime();

            if(arrayTh[i].usoThread == Delete){
                free(arrayTh[i].stack);
                newthread.stack = malloc(stacksize);
            }else{
                newthread.stack = malloc(stacksize);
            }

            newthread.timeSleep =0; 

            newthread.context.uc_stack.ss_sp = newthread.stack;
            newthread.context.uc_stack.ss_size = stacksize;
            newthread.context.uc_link = NULL;

            arrayTh[i]= newthread;
            makecontext(&(arrayTh[i].context), (void(*)(void))mainf, 1,arg);
            break;
        } 
      }
    return id;  
}

void
yieldthread(void){
    int i;
    for (i=0;i<sizeArrayThreads;i++){
        if(arrayTh[i].usoThread==Using){
            initTime();
            if(initTime() - arrayTh[i].t < 200){
                break;
            }else{
                arrayTh[i].usoThread= Ready;
                while(scheduler(i) !=0);
                break;
            }
        }
    }
}

static void
funcDelete(int i){
    free(arrayTh[i].stack);
    arrayTh[i].id=0;
    arrayTh[i].usoThread=Free;
    arrayTh[i].t=0;
}
static void
funcScheduler(int i, int j){
    arrayTh[i].usoThread = Using;
    arrayTh[i].t= initTime();
    swapcontext(&(arrayTh[j].context), &(arrayTh[i].context));
}

void 
functionSleep(int i){
    if(initTime() - arrayTh[i].t > arrayTh[i].timeSleep ){
        arrayTh[i].usoThread = Ready;
    }
}

int
scheduler (int j){
    int i;
    int changeSwap;
    changeSwap=0;
    int isSleeping;
    isSleeping=0;

    for(i = j+1; i <=j+sizeArrayThreads;i++){
	int i1=i;
	if(i>=sizeArrayThreads){
		i1=i%(sizeArrayThreads);
	}
	if(arrayTh[i1].usoThread == Delete){
           funcDelete(i1);
        }else if(arrayTh[i1].usoThread==Sleep){
          functionSleep(i1);
        }

        if(arrayTh[i1].usoThread == Ready){
          funcScheduler(i1,j);
          changeSwap=1;
          break;
        }
    }


    if(changeSwap == 0){
      if(arrayTh[j].usoThread == Ready){
          arrayTh[j].usoThread = Using;
      }else{
        for (i = 0; i <sizeArrayThreads; ++i){
          if(arrayTh[i].usoThread == Sleep){
            functionSleep(i);
            isSleeping = 1;
          }
        }
        if(isSleeping ==0){
          for (i = 0; i <sizeArrayThreads; ++i){
            if(arrayTh[i].usoThread == Suspend){
              fprintf(stderr, "%s\n", "Err: Thread Suspend");
              exit(1);
            }
          }
        }
      }
    }

    return isSleeping;
}

void
exitsthread(void){
    int i;
    for (i=0;i<sizeArrayThreads;i++){
        if (arrayTh[i].usoThread == Using){
            arrayTh[i].usoThread=Delete;
            while(scheduler(i) !=0);
            break;
        }
    }
    for (i=0;i<sizeArrayThreads;i++){
        if (arrayTh[i].usoThread == Using){
            arrayTh[i].usoThread=Delete;
            while(scheduler(i) !=0);
            break;
        }
    }
    for(i=0; i<sizeArrayThreads; i++){
    	if(arrayTh[i].usoThread == Suspend){
    		fprintf(stderr, "%s\n", "Err: Thread Suspend");
        	break;
        }
    }
}

int
curidthread(void){
    int i;
    for (i=0;i<sizeArrayThreads;i++){
        if(arrayTh[i].usoThread==Using)
            return arrayTh[i].id;
        }
    return 0;
}


static long long 
initTime(){
    struct timeval t_ini;
    gettimeofday(&t_ini, NULL);
    long long int r= (((long long)(t_ini.tv_usec*0.001))+ ((long long)t_ini.tv_sec)*1000);
    return r;
}




void
suspendthread(void){
    int i;
    for (i=0;i<sizeArrayThreads;i++){
        if(arrayTh[i].usoThread == Using){
            arrayTh[i].usoThread=Suspend;
            while(scheduler(i) !=0);
            break;
        }
    }
}

int
resumethread(int id){
      int i;
      for (i=0; i <sizeArrayThreads; i++){
          if(arrayTh[i].id == id && arrayTh[i].usoThread == Suspend){
              arrayTh[i].usoThread = Ready;
              return 0;
          }
      }
      return -1;
}


int
killthread(int id){
      int i;
      for (i=0; i<sizeArrayThreads; i++){
          if(arrayTh[i].id == id){
              if(arrayTh[i].usoThread == Using){
                  arrayTh[i].usoThread = Delete;
                  while(scheduler(i) !=0);
                  return 0;
              }else{
                  arrayTh[i].usoThread = Delete;
                  return 0;
              }
          }
      } 
      return -1;        
}


void
sleepthread(int msec){
      int i;
      for(i=0; i <sizeArrayThreads; i++){
          if(arrayTh[i].usoThread == Using){
              arrayTh[i].usoThread = Sleep;
              arrayTh[i].t = initTime();
              arrayTh[i].timeSleep = msec;
              while(scheduler(i)!=0);
              break;
          }
      }
}



int 
suspendedthreads(int **list){
      int i;
      int numSuspend;
      numSuspend =0;
      int j;
      j=0;
      for(i=0; i < sizeArrayThreads; i++){
          if(arrayTh[i].usoThread == Suspend){
            numSuspend++;
          }
      }

      if(numSuspend !=0){
          int* arraySleep = malloc(sizeof(int)*numSuspend);
          for(i=0; i <sizeArrayThreads; i++){ 
              if(arrayTh[i].usoThread == Suspend){
                arraySleep[j]= arrayTh[i].id;
                j++;
              }
          }
          *list = arraySleep;
      }
      return numSuspend;
}

