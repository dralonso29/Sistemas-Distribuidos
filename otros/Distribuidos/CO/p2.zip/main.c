//Jorge Vela Peña
//Grado en Ingeniería Telemática


#include <stdio.h>
#include "threads.h"
#include <time.h>
#include <unistd.h>

void f2();
void f3();
void f4();
void f5();

void f2(){
	int i;
	sleepthread(2000);

	for(i=0; i < 20; i++){
		printf("F2 %d\n", i);
		usleep(100000);
		yieldthread();
		if(i==16){
			resumethread(2);
		}
	}
	sleepthread(2000);
	printf("FIN F2-------------------------------------------------------------\n");
	exitsthread();
}

void f3(){
	int i;
	suspendthread();

	for(i=0; i < 20; i++){
		printf("F3 %d\n", i);
		usleep(100000);
		if(i==4){
			createthread(f4, NULL ,64*1024);
			sleepthread(2000);
		}
		yieldthread();
	}


	printf("FIN F3-------------------------------------------------------------\n");
	exitsthread();
}

void f5(){
	for(int i=0; i < 20; i++){
		printf("F5 \n");
		usleep(100000);
		yieldthread();
	}
	printf("FIN F5-------------------------------------------------------------\n");
	exitsthread();
}
void f4(){
	int i;

	killthread(8);

	for(i=0; i < 20; i++){
		printf("F4 %d\n", i);
		usleep(100000);
		yieldthread();
	}
	suspendthread();
	printf("FIN F4-------------------------------------------------------------\n");
	exitsthread();
}

int main (int argc,char **argv)
{
	int i;
	initthreads();

	int *a;
	suspendedthreads(&a);


	createthread(f2, NULL ,64*1024);
	createthread(f3, NULL ,64*1024);
	createthread(f5,NULL,64*1024);
	
	for (i=0; i<20;i++){
		printf("Main %d\n", i);
		usleep(100000);
		yieldthread();
	}
	printf("%s\n", "Main FIN ------------------------------------------------------");

	exitsthread();
	return 0;
}
