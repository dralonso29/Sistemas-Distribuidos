package rendez

import (
	"testing"
)

func TestFirst (t *testing.T){
	//doMap()
	
	 Rendezvous(1,1)
	 Rendezvous(2,2)
	
	printMap()
		
}


