
package logorder


import(
	"fmt"
	"logicclock"
)