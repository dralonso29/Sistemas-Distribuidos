

package logorder

import(
	"fmt"
	"testing"
)



func TestOne(t *testing.T){
	fmt.Println("H")
	ReadFile("/tmp/dat2")
}
