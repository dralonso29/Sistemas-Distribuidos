//Eva Gordo Calleja
//Grado telemática

package custod

import (
	"container/list"
	"sync"
)

